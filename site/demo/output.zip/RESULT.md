This is a demo of darner, and there's no model on the other end. No sandbox was started, and nothing you typed left your browser.

On a real darner, your task would now be running as an isolated [dejima](https://dejima.page) session on the dejima host, with the settings you chose. Its page would show its output once the agent wrote `~/shared/RESULT.md` and signalled it was done, with everything else it left in `~/shared` as a zip. Until then, you could send it a message, upload a file into its `~/shared/uploads`, and allow or deny the domains it asks for.

This output came the way a real session's does: from the stub launcher this demo was built with, through darner's API, cleaned and shown as text written by an agent, which is why it's labelled as the agent's. **Self-test** sends text written like a hostile agent's down the same path, to show what this page does with it.
